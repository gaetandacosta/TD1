# <img src="iut.png" width="17%" style="margin:auto;display:block;"/> Qualité de développement 
### IUT Montpellier-Sète – Département Informatique
* **Cours:** [R3.04 - Qualité de Développement @ MOODLE]
* **Enseignant:** [Malo Gasquet](mailto:malo.gasquet@umontpellier.fr), [Gaelle Hisler](mailto:gaelle.hisler@umontpellier.fr), [Nadjib Lazaar](mailto:nadjib.lazaar@umontpellier.fr), [Nathalie Palleja](mailto:nathalie.palleja@umontpellier.fr),   [Simon Robillard](mailto:simon.robillard@umontpellier.fr), [Bruno Rouchon](mailto:bruno.rouchon@umontpellier.fr)
* [Fiche TD2](TD2.pdf).

* Lien classroom :
* * [Groupe Q1](https://classroom.github.com/a/F1kk7MGn)
* * [Groupe Q2](https://classroom.github.com/a/kjtWs8qF)
* * [Groupe Q3](https://classroom.github.com/a/gRfKUxGY)
* * [Groupe Q4](https://classroom.github.com/a/kLd66FpA)
* * [Groupe Q5](https://classroom.github.com/a/gcNfnHVW)
